Stake Helper - DEMO-ONLY source project

This project is intended for demo-account testing and simulation only.
It is not a guarantee of profitable predictions. Do not use with real-money
binary options. Keep the demo-account guard enabled.

Current requested defaults:
- Sheet capital: 5500
- Payout filter: 88%
- Restart rules: 1:1, 2:1, 5:2, 8:3, 11:4, 16:5
- Daily target: 2750 profit above the session starting balance
- Daily win-stop thresholds: 11:2, 12:3, 14:4, 16:5
- Stop after 9 consecutive losses (the counter/stop integration still needs
  implementation and verification before treating this as complete).

Build:
1. Upload all files and folders, including .github, to a GitHub repository.
2. Open Actions -> Build APK.
3. Download the StakeHelper-APK artifact after the workflow succeeds.

Important: This source bundle has not been built or device-tested here.
The service's existing auto-tap behavior is not verified. Test only in demo mode.
