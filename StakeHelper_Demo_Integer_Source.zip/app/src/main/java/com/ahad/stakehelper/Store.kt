package com.ahad.stakehelper

import android.content.Context
import java.util.Locale

object Shared {
    @Volatile var lastPkg: String = ""
    @Volatile var lastDump: String = ""
}

class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun d(k: String, def: Double): Double = p.getString(k, null)?.toDoubleOrNull() ?: def
    fun i(k: String, def: Int): Int = p.getString(k, null)?.toIntOrNull() ?: def
    fun s(k: String, def: String): String = p.getString(k, null) ?: def
    fun put(k: String, v: String) { p.edit().putString(k, v).apply() }

    val capital: Double get() = d("capital", 5500.0)       // ভার্চুয়াল ক্যাপিটাল (শীটের I5)
    val events: Int get() = i("events", 17)                 // মোট ইভেন্ট
    val expWins: Int get() = i("expwins", 5)                // আশা করা জয়
    val stopLevel: Double get() = d("stop", capital / 2.0)  // ক্যাশ এর নিচে নামলে STOP
    val expiry: Int get() = i("expiry", 60)                 // ট্রেড মেয়াদ (সেকেন্ড)
    val quota: Double get() = d("quota", 1.89)              // শীটের কোটা — স্টেক হিসাবে সবসময় এটাই ব্যবহার হয়
    val minPayout: Int get() = i("minpay", 88)              // এর নিচে পেআউট হলে ট্রেড করা হবে না
    val pkg: String get() = s("pkg", "qx,quotex")           // লক্ষ্য অ্যাপের প্যাকেজ-নামের অংশ
    // নতুন সাইকেলের নিয়ম "ট্রেডসংখ্যা:জয়", যেমন 5:2 = ৫ ট্রেডের মধ্যে ২ জয় হলেই নতুন সাইকেল
    val restartRules: List<Pair<Int, Int>>
        get() = s("rules", "1:1,5:2,8:3,11:4").split(",").mapNotNull {
            val a = it.trim().split(":")
            val n = if (a.size == 2) a[0].trim().toIntOrNull() else null
            val k = if (a.size == 2) a[1].trim().toIntOrNull() else null
            if (n != null && k != null) Pair(n, k) else null
        }
    val demoGuard: Boolean get() = s("demoguard", "1") == "1"   // শুধু ডেমোতে অটো-ট্রেড
    val cooldown: Int get() = i("cooldown", 2)                  // ট্রেডের পর বিরতি (সেকেন্ড)
    val maxCycles: Int get() = i("maxcycles", 0)                // দিনে সর্বোচ্চ সফল সার্কেল (0 = সীমা নেই)
    val dailyTarget: Double get() = d("dailytarget", capital / 2.0)  // দিনের লাভ এতে পৌঁছালে সেদিন বন্ধ (0 = বন্ধ)
    val candleClose: Boolean get() = s("candleclose", "1") == "1"    // ট্রেড ক্যান্ডেল ক্লোজে শেষ হয়
    val clockOffset: Int get() = i("clockoffset", 0)                 // ফোনের ঘড়ি ও Quotex ক্যান্ডেলের সেকেন্ডের ফারাক
    val analyzeStart: Int get() = i("analyzestart", 6)               // ক্যান্ডেল শুরুর কত সেকেন্ডের মধ্যে বিশ্লেষণ শুরু
    val entryWindow: Int get() = i("entrywindow", 25)                // ক্যান্ডেলের কত সেকেন্ডের মধ্যে ট্রেড নেওয়া যাবে
    val settle: Int get() = i("settle", 3)                           // ক্লোজের কত সেকেন্ড পরে ফলাফল দেখা শুরু
    val resultCheck: Boolean get() = s("resultcheck", "1") == "1"    // ব্যালেন্স না বাড়লে এআই দিয়ে স্ক্রিন দেখে যাচাই
}

class Engine(private val cfg: Cfg) {
    var cash = 0.0
    var trades = 0
    var wins = 0
    var stopped = false
    var lastBank = 0.0      // সার্কেল সম্পূর্ণ হলে জমা হওয়া লাভ
    private var snap: String? = null

    init { load() }

    private fun load() {
        cash = cfg.d("st_cash", cfg.capital)
        trades = cfg.i("st_trades", 0)
        wins = cfg.i("st_wins", 0)
        stopped = cfg.s("st_stopped", "0") == "1"
    }

    private fun save() {
        cfg.put("st_cash", cash.toString())
        cfg.put("st_trades", trades.toString())
        cfg.put("st_wins", wins.toString())
        cfg.put("st_stopped", if (stopped) "1" else "0")
    }

    fun reset() {
        cash = cfg.capital
        trades = 0
        wins = 0
        stopped = false
        save()
    }

    fun stake(q: Double): Double {
        if (stopped) return 0.0
        return Masaniello.stake(cash, cfg.events - trades, cfg.expWins - wins, q)
    }

    // delta = এই ট্রেডে ব্যালেন্সের পরিবর্তন (জিতলে +লাভ, হারলে -স্টেক)
    // ফেরত: "RESTART" (১ম ট্রেড জিতে নতুন সাইকেল), "DONE" (সার্কেল সফল), "BROKEN" (সার্কেল ব্যর্থ), "" (চলছে)
    fun onResult(win: Boolean, delta: Double): String {
        snap = "$cash|$trades|$wins|${if (stopped) 1 else 0}"
        cash += delta
        trades++
        if (win) wins++
        if (win && cfg.restartRules.any { trades <= it.first && wins >= it.second }) {
            lastBank = cash - cfg.capital
            reset()
            return "RESTART"
        }
        if (wins >= cfg.expWins) {
            lastBank = cash - cfg.capital
            reset()
            return "DONE"
        }
        var broken = false
        if (cash <= cfg.stopLevel) broken = true                           // আসল ক্যাপিটাল শেষ
        if (cfg.events - trades < cfg.expWins - wins) broken = true        // আর জেতার উপায় নেই
        if (broken) stopped = true
        save()
        return if (broken) "BROKEN" else ""
    }

    fun undo() {
        val s = snap ?: return
        val parts = s.split("|")
        if (parts.size < 4) return
        cash = parts[0].toDoubleOrNull() ?: cash
        trades = parts[1].toIntOrNull() ?: trades
        wins = parts[2].toIntOrNull() ?: wins
        stopped = parts[3] == "1"
        snap = null
        save()
    }
}

object TradeLog {
    // লাইন: সময়|দিক|স্টেক|W/L|ফলাফল-কোড|ট্রেড নম্বর
    fun add(cfg: Cfg, line: String) {
        val old = cfg.s("log", "")
        val lines = if (old.isEmpty()) mutableListOf<String>() else old.split("\n").toMutableList()
        lines.add(line)
        while (lines.size > 600) lines.removeAt(0)
        cfg.put("log", lines.joinToString("\n"))
    }

    fun stats(cfg: Cfg): String {
        val lines = cfg.s("log", "").split("\n").filter { it.isNotBlank() }
        var w = 0
        var l = 0
        var done = 0
        var broken = 0
        for (ln in lines) {
            val p = ln.split("|")
            if (p.size < 5) continue
            if (p[3] == "W") w++ else l++
            if (p[4] == "RESTART" || p[4] == "DONE") done++
            if (p[4] == "BROKEN") broken++
        }
        val t = w + l
        val rate = if (t > 0) String.format(Locale.US, "%.1f", w * 100.0 / t) else "-"
        return "মোট ট্রেড $t • জয় $w • হার $l • জয়ের হার $rate%\nসফল সার্কেল $done • ব্যর্থ সার্কেল $broken"
    }
}
