package com.ahad.stakehelper

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Analyzer {
    class Result(val dir: String, val note: String)

    private const val PROMPT =
        "This is a screenshot of a 1-minute candlestick chart from a binary options trading app. " +
        "A new 1-minute candle has just opened; the fully closed candles are to its left. " +
        "Judge the recent candles: trend, momentum, and nearby support/resistance. " +
        "Decide whether the NEW candle (next 1 minute) will close HIGHER (UP) or LOWER (DOWN) than its open. " +
        "Answer UP or DOWN only when there is a clear, high-probability setup (e.g. clean trend continuation, " +
        "strong rejection at support/resistance). If the market is choppy, ranging, unclear, or the chart is not " +
        "visible, answer SKIP. " +
        "Reply with ONLY a JSON object, nothing else: {\"dir\":\"UP\" or \"DOWN\" or \"SKIP\",\"conf\":0-100,\"why\":\"short reason\"}"

    private const val RESULT_PROMPT =
        "This is a screenshot of a binary options trading app taken right after a trade should have expired. " +
        "Find the result of the MOST RECENT trade: a win/profit is usually shown in green or with a '+' amount; " +
        "a loss is usually shown in red or with a '-' amount or $0 return. " +
        "If the trade still appears to be open/running, answer RUNNING. If you cannot tell, answer UNKNOWN. " +
        "Reply with ONLY a JSON object, nothing else: {\"result\":\"WIN\" or \"LOSS\" or \"RUNNING\" or \"UNKNOWN\"}"

    fun analyze(cfg: Cfg, src: Bitmap): Result {
        return try {
            parseDir(ask(cfg, src, PROMPT))
        } catch (e: Exception) {
            Result("ERR", e.message ?: "ত্রুটি")
        }
    }

    fun checkResult(cfg: Cfg, src: Bitmap): Result {
        return try {
            parseResult(ask(cfg, src, RESULT_PROMPT))
        } catch (e: Exception) {
            Result("ERR", e.message ?: "ত্রুটি")
        }
    }

    private fun ask(cfg: Cfg, src: Bitmap, prompt: String): String {
        val key = cfg.s("apikey", "").trim()
        if (key.isEmpty()) throw RuntimeException("API কী দেওয়া হয়নি")
        val bmp = scale(src, 900)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, bos)
        val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        return if (cfg.s("provider", "gemini").trim().lowercase() == "claude")
            callClaude(cfg, key, b64, prompt) else callGemini(cfg, key, b64, prompt)
    }

    private fun scale(b: Bitmap, w: Int): Bitmap {
        if (b.width <= w) return b
        val h = (b.height * w.toDouble() / b.width).toInt()
        return Bitmap.createScaledBitmap(b, w, h, true)
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 45000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: " + txt.take(160))
        return txt
    }

    private fun callGemini(cfg: Cfg, key: String, b64: String, prompt: String): String {
        val model = cfg.s("model", "").trim().ifEmpty { "gemini-2.5-flash" }
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.2))
            .toString()
        val resp = post(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            mapOf("x-goog-api-key" to key), body
        )
        val ps = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
        return sb.toString()
    }

    private fun callClaude(cfg: Cfg, key: String, b64: String, prompt: String): String {
        val model = cfg.s("model", "").trim().ifEmpty { "claude-sonnet-5-5" }
        val content = JSONArray()
            .put(
                JSONObject().put("type", "image").put(
                    "source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)
                )
            )
            .put(JSONObject().put("type", "text").put("text", prompt))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 200)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            .toString()
        val resp = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body
        )
        val arr = JSONObject(resp).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text", ""))
        return sb.toString()
    }

    private fun obj(text: String): JSONObject? {
        val a = text.indexOf('{')
        val b = text.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return JSONObject(text.substring(a, b + 1))
    }

    private fun parseDir(text: String): Result {
        val o = obj(text) ?: return Result("ERR", "এআই-র উত্তর বোঝা যায়নি")
        val dir = o.optString("dir", "").trim().uppercase()
        val note = "conf " + o.optInt("conf", -1) + " • " + o.optString("why", "")
        return if (dir == "UP" || dir == "DOWN" || dir == "SKIP") Result(dir, note)
        else Result("ERR", "অজানা দিক: $dir")
    }

    private fun parseResult(text: String): Result {
        val o = obj(text) ?: return Result("ERR", "এআই-র উত্তর বোঝা যায়নি")
        val r = o.optString("result", "").trim().uppercase()
        return if (r == "WIN" || r == "LOSS" || r == "RUNNING" || r == "UNKNOWN") Result(r, "")
        else Result("ERR", "অজানা ফলাফল: $r")
    }
}
