StakeHelper DEMO source bundle

GitHub Actions supports either:
1) Uploading this ZIP file as a file in the repository root; the workflow will extract it and build the Android project, or
2) Extracting this archive and uploading all contained project files/folders to the repository root.

Important:
- This is source code, not a prebuilt APK.
- A successful build does not prove automatic trading works on Quotex. Test only in DEMO.
- The workflow requires Android Gradle project files such as settings.gradle.kts and app/build.gradle.kts.
